# McHacks2021
This repository is created and maintained with the collaborative efforts of Angela Zhao, Esteban Mendez, Ethan Tian(Yuxuan Tian), and Javin Liu.
To be used for McHacks2021.
